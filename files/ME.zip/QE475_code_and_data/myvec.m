function vecA=myvec(A)
%name: VEC
%vecA=vec(A)
vecA=reshape(A,numel(A),1);
