% Main prg to run the BM asymmetric estimation

%clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initialization/Parametrization of routine
setup_NL_bivariate;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%To find starting values (or, in our case, priors), match IRFs with those of VAR:

VAR_resp_match_NL;



%set prior

%In practical applications, the resulting parameter values can be used as starting values
%setup.initial_parameter=[zeros(setup.size_obs,1);poly_coefficients(:);beta_diag;beta2(:);b2(:);c2(:);beta_diag;beta2(:);b2(:);c2(:)];

%Here we just use them as a prior
setup.normal_prior_means=[zeros(setup.size_obs,1);poly_coefficients(:);beta_diag;beta2(:);b2(:);c2(:);beta_diag;beta2(:);b2(:);c2(:)];

%setup.normal_prior_means=[0 0 1 .5 2 10 -10 100 450 5 2.5 10 10 -10 100 450]';
setup.normal_prior_std=abs([1e-10 1e-10 2*setup.normal_prior_means(3:end)']');
setup.index_normal=1:length(setup.normal_prior_means);
setup.index_gamma=[];
close all;

setup.initial_parameter=setup.normal_prior_means; %starting value for optimizers (which in turn return starting value for MCMC)
setup.initial_parameter=[0 0 1 .5 2 10 -10 100 450 5 2.5 10 10 -10 100 450]';

setup.length_param_vector=length(setup.initial_parameter);



%estimation
[ draws, acc_rate, log_posteriors, statedraws, add_matrices] = sampling_MH_MC_GB( setup );
%add_matrices are the estimated shocks





