% master file for MC simulations 

clear;
close all;
clc;
tic

fileroot=pwd;
number_simul=1; %number of simulations
%we will use 2 obs
size_obs=2;
%length of simulation
length_simul=200;

lags=40;





for nn=1:number_simul
%storing across simulations
Atrue(:,:,nn)=[2 .5;-.5 2];
B(:,:,nn)=[5 10; 7 -10];
C(:,:,nn)=[300/2 200/2; 200/2 900/2];
INIT(:,:,nn)=[1 0;-.1 1];


shocks=zeros(size_obs,length_simul+lags);

shocks(:,lags+1:end)=randn([size_obs length_simul]); %initial shocks set to 0

SHOCKS(:,:,nn)=shocks;

data=zeros(size_obs,length_simul);


for ll=1:lags
Sigma(:,:,ll)=SL_NL_symmetric( Atrue(:,:,nn),B(:,:,nn),C(:,:,nn),ll );
end



A_NEG(:,:,nn)=Atrue(:,:,nn);
B_NEG(:,:,nn)=B(:,:,nn);
C_NEG(:,:,nn)=C(:,:,nn);
INIT_NEG(:,:,nn)=INIT(:,:,nn);

%creating asymmetry in DGP
A_POS(:,:,nn)=Atrue(:,:,nn);
A_POS(:,2,nn)=5*A_POS(:,2,nn);
B_POS(:,:,nn)=B(:,:,nn);
B_POS(:,:,nn)=B_POS(:,:,nn);
C_POS(:,:,nn)=C(:,:,nn);
INIT_POS(:,:,nn)=INIT(:,:,nn);
INIT_POS(:,2,nn)=5*INIT_POS(:,2,nn);


for ll=1:lags
Sigma_pos(:,:,ll)=SL_NL_symmetric( A_POS(:,:,nn),B_POS(:,:,nn),C_POS(:,:,nn),ll);
end
SIGMA_POS(:,:,:,nn)=Sigma_pos; 

for ll=1:lags
Sigma_neg(:,:,ll)=SL_NL_symmetric(A_NEG(:,:,nn),B_NEG(:,:,nn),C_NEG(:,:,nn),ll );
end
SIGMA_NEG(:,:,:,nn)=Sigma_neg;
data=zeros(size_obs,length_simul);

if nn==1

figure;
for pp=1:4
    ind_vec=[1 3 2 4];
subplot(2,2,pp);
[I, J]=ind2sub([2,2],ind_vec(pp));
plot([INIT_POS(ind_vec(pp)) squeeze(SIGMA_POS(I,J,:))'],'LineWidth',2)
grid on
title('true response to positive shocks')
end

figure;
for pp=1:4
subplot(2,2,pp);
[I, J]=ind2sub([2,2],ind_vec(pp));
plot([INIT_NEG(ind_vec(pp)) squeeze(SIGMA_NEG(I,J,:))'],'LineWidth',2)
grid on
title('true response to negative shocks')
end
end

for kk=1:length_simul
    if shocks(2,kk+lags)>0
data(:,kk)=INIT_POS(:,:,nn)*shocks(:,kk+lags);
    else
     data(:,kk)=INIT_NEG(:,:,nn)*shocks(:,kk+lags);   
    end
for jj=1:lags
    if shocks(2,kk+lags-jj)>0
data(:,kk)=Sigma_pos(:,:,jj)*shocks(:,kk+lags-jj)+data(:,kk);
    else
     data(:,kk)=Sigma_neg(:,:,jj)*shocks(:,kk+lags-jj)+data(:,kk);   
    end
end
end

if nn==1
true_pos=zeros(2,2,lags+1);
true_pos(:,:,2:end)=SIGMA_POS(:,:,:,nn);
true_pos(:,:,1)=INIT_POS(:,:,nn);

true_neg=zeros(2,2,lags+1);
true_neg(:,:,2:end)=SIGMA_NEG(:,:,:,nn);
true_neg(:,:,1)=INIT_NEG(:,:,nn);

save true_asymmetry true_pos true_neg
end
DATA_ASY(:,:,nn)=data;

 save([fileroot,'/Asymmetric_irf_code/Data/data_file2.mat'],'data');

%estimation
Principal_MC_GB;
DRAWS_ASY(:,:,nn)=draws;
ADD_MATRICES_ASY(:,:,:,nn)=add_matrices;
ACC_RATE_ASY(:,nn)=acc_rate;
LOG_POS_ASY(:,nn)=log_posteriors;
plots_irfs
end

toc

save MC_results_GB

